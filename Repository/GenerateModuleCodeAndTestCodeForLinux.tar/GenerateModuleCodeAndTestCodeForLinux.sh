#!/bin/bash
# Copyright (c) 2013. lin_jie_long@126.com, 2013-6-24. All rights reserved.
#
# GenerateModuleCodeForLinux.sh
#
# $1 --- the filename of the module code.

if [ $# != 1 ]; then
    echo Usage:
    echo "  %0  <module_name>"
    exit 0
fi

if [ -e "DRV_$1" ]; then
    echo "Skipped: DRV_$1 is exist."
else

mkdir -pv  DRV_$1

cat > DRV_$1/$1.c << "EOF"
/*
 * Copyright (c) 2013.  lin_jie_long@126.com, 2013. All rights reserved.
 */
EOF

echo "/* $1.c" >> DRV_$1/$1.c

cat >> DRV_$1/$1.c << "EOF"
 *
 */

#include <linux/init.h>        /* module_init  module_exit */
#include <linux/module.h>      /* MODULE_LINCENSE */
#include <linux/kernel.h>      /* printk */

#include <linux/fs.h>          /* struct file_operations */
#include <linux/cdev.h>        /* struct cdev */
#include <linux/types.h>       /* dev_t */
#include <linux/kdev_t.h>      /* MAJOR(..) MINOR(..) MKDEV(..) */
#include <linux/slab.h>        /* kmalloc  kfree */ 
#include <linux/ioport.h>      /* release_mem_region */

#include <asm/uaccess.h>       /* copy_from_user */
#include <asm/io.h>            /* ioremap */

#include <linux/semaphore.h>   /* sync */
#include <linux/errno.h>

#define  virt_cdev_debug() printk("<6>""%s:%s:%d\r\n", __FILE__, __FUNCTION__, __LINE__)

typedef struct _VIRT_CDEV_T {
    int               regval;  /* the valure of register for virt_cdev */
    struct semaphore  sem;     /* sync for 'regval' */
    struct cdev       dev;     /* virt_cdev is a char dev by struct cdev. */
} VIRT_CDEV_T;

static VIRT_CDEV_T*   gpt_virt_cdev;


static ssize_t  virt_cdev_open(struct  inode *inode, struct file *file)
{
    VIRT_CDEV_T*  pt_virt_cdev;
    
    virt_cdev_debug();
    pt_virt_cdev = container_of(inode->i_cdev, VIRT_CDEV_T, dev);
    file->private_data = pt_virt_cdev;
    
    return 0;
}

static int virt_cdev_release(struct inode *inode, struct file *file)
{
    virt_cdev_debug();
    return 0;
}

static ssize_t virt_cdev_read(struct file *file, char __user *buf, size_t count, loff_t *ppos)
{
    VIRT_CDEV_T*  pt_virt_cdev;
    
    virt_cdev_debug();
    pt_virt_cdev = (VIRT_CDEV_T*)file->private_data;
    /* Sync */
    if (down_interruptible(&pt_virt_cdev->sem)) {
        printk("<6>" "down_interruptible(&pt_virt_cdev->sem) == 1\r\n");
        return -ERESTARTSYS;
    }

    if (count != sizeof(pt_virt_cdev->regval)) {
        printk("<6>" "count is too big\r\n");
        up(&pt_virt_cdev->sem);
        return -EFAULT;
    }

    if (copy_to_user(buf, &pt_virt_cdev->regval, count)) {
        printk("<6>" "copy_to_user is FAULT\r\n");
        up(&pt_virt_cdev->sem);
        return -EFAULT;
    }
    up(&pt_virt_cdev->sem);

    return count;
}

static ssize_t virt_cdev_write(struct file *file, const char __user *buf, size_t count, loff_t *ppos)
{
    VIRT_CDEV_T*  pt_virt_cdev;
    
    virt_cdev_debug();
    pt_virt_cdev = (VIRT_CDEV_T*)file->private_data;
    /* Sync */
    if (down_interruptible(&pt_virt_cdev->sem)) {
        printk("<6>" "down_interruptible(&pt_virt_cdev->sem) == 1\r\n");
        return -ERESTARTSYS;
    }

    if (count != sizeof(pt_virt_cdev->regval)) {
        printk("<6>" "count is too big\r\n");
        up(&pt_virt_cdev->sem);
        return -EFAULT;
    }

    if (copy_from_user(&pt_virt_cdev->regval, buf, count)) {
        printk("<6>" "copy_from_user is FAULT\r\n");
        up(&pt_virt_cdev->sem);
        return -EFAULT;
    }
    up(&pt_virt_cdev->sem);

    return count;
}

static int virt_cdev_ioctl(struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg)
{
    printk("<6>" "cmd=%d  arg=%d\r\n", (int)cmd, (int)arg);
    virt_cdev_debug();

    return 0;
}


static struct file_operations  virt_cdev_fops = {
    .owner = THIS_MODULE,
    .open = virt_cdev_open,
    .read = virt_cdev_read,
    .write = virt_cdev_write,
    .release = virt_cdev_release,
    .ioctl = virt_cdev_ioctl,
};

static  dev_t   virt_cdev_devid;
static  dev_t   virt_cdev_major_devid = 200;

static  const   char  *virt_cdev_devname = "virt_char_dev";

/* The targets to init the char device:
 *     int cdev_add(struct cdev * p, dev_t dev, unsigned count);
 *     init the registers about the specified char device.
 */
static  int  virt_cdev_init(void)
{
    /* Get DevID */
    if (virt_cdev_major_devid) {
        virt_cdev_devid = MKDEV(virt_cdev_major_devid, 0);
        if (register_chrdev_region(virt_cdev_devid, 1, virt_cdev_devname) < 0) {
            printk("<6>" "Failed to register_chrdev_region\r\n");
            return -1;
        }
    } else {
        if (alloc_chrdev_region(&virt_cdev_devid, 0, 1, virt_cdev_devname) < 0) {
            printk("<6>" "Failed to alloc_chrdev_region\r\n");
            return -1;
        }
        virt_cdev_major_devid = MAJOR(virt_cdev_devid);
    }

    /* Init virt_cdev */
    if (gpt_virt_cdev != NULL) {
        unregister_chrdev_region(virt_cdev_devid, 1);
        printk("<6>" "virt_cdev is exist\r\n");
        return -1;
    }
    gpt_virt_cdev = kmalloc(sizeof(VIRT_CDEV_T), GFP_KERNEL);
    if (gpt_virt_cdev == NULL) {
        unregister_chrdev_region(virt_cdev_devid, 1);
        return -1;
    }
    memset(gpt_virt_cdev, 0, sizeof(VIRT_CDEV_T));
    gpt_virt_cdev->dev.owner = THIS_MODULE;
    cdev_init(&gpt_virt_cdev->dev, &virt_cdev_fops);
    if (cdev_add(&gpt_virt_cdev->dev, virt_cdev_devid, 1)) {
        unregister_chrdev_region(virt_cdev_devid, 1);
        printk("<6>" "Failed to cdev_add\r\n");
        return -1;
    }
    init_MUTEX(&gpt_virt_cdev->sem);
    gpt_virt_cdev->regval = 0x00000000;

    printk("<6>" "virt_cdev_init - devid=0x%x\r\n", virt_cdev_devid);
    return 0;
}

/*
 * The targets to exit the char device:
 *     void cdev_del(struct cdev * p);
 */
static void  virt_cdev_exit(void)
{
    if (gpt_virt_cdev != NULL) {
        unregister_chrdev_region(virt_cdev_devid, 1);
        cdev_del(&gpt_virt_cdev->dev);
        kfree(gpt_virt_cdev);
        gpt_virt_cdev = NULL;
    }

    printk("<6>" "virt_cdev_exit\r\n");
}


module_init(virt_cdev_init);
module_exit(virt_cdev_exit);

MODULE_LICENSE("Dual BSD/GPL");
MODULE_AUTHOR("lin_jie_long@126.com");
MODULE_DESCRIPTION("to study the develop of the char device.");

EOF

fi


if [ -e "APP_$1" ]; then
    echo "Skipped: APP_$1 is exist."
else

mkdir -pv APP_$1

#########   AppTest  ########

cat > APP_$1/test.c << "EOF"
/*
 * Copyright (c) 2013.  lin_jie_long@126.com, 2013. All rights reserved.
 */
EOF

echo "/* test.c" >> APP_$1/test.c

cat >> APP_$1/test.c << "EOF"
 *
 */

#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <linux/fb.h>
#include <linux/kd.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <sys/time.h>
#include <string.h>
#include <errno.h>

int main(int argc, char **argv)
{
    int fd;
    int buf;

    system("dmesg -c;echo;");

    system("rm -rf /dev/virt_char_dev 2>/dev/null");
    system("mknod /dev/virt_char_dev c 200 0  2>/dev/null");

    fd = open("/dev/virt_char_dev", O_RDWR);
    if (fd < 0) {
        printf("Failed to open: errno=0x%x\r\n", errno);
        return -1;
    }
    write(fd, "1234", 4);

    buf = 0;
    read(fd, (char *)&buf, 4);
    printf("buf=0x%x\r\n", (int)buf);

    ioctl(fd, 111, 222);
    
    close(fd);
    system("echo;echo;dmesg -c;echo;");

    return 0;
}

EOF

fi

#########  Makefile #########

if [ -e "DRV_$1/Makefile" ]; then
    echo "Skipped: Makefile is exist."
else

cat > DRV_$1/Makefile << "EOF"
# Copyright(c)  2012-2017,  lin_jie_long@126.com.  All rights reserved.
# Created by lin_jie_long@126.com, 2012-12-5

SOURCE = $(wildcard *.c)
OBJECT = $(patsubst %.c, %.o, $(SOURCE))

kernel_dir := /lib/modules/`uname -r`/build
export OBJECT

all::
	@make -C $(kernel_dir) M=`pwd` modules
clean:
	@make -C $(kernel_dir) M=`pwd` clean
	@rm -rf *.markers  *.order

EOF

fi

############  Kbuild #############

if [ -e  "DRV_$1/Kbuild" ]; then
    echo "Skipped: Kbuild is exist."
else

cat > DRV_$1/Kbuild << "EOF"
# Copyright(c)  2012-2017,  lin_jie_long@126.com.  All rights reserved.
# Created by lin_jie_long@126.com, 2012-12-5

obj-m := hk.o
hk-y := $(OBJECT)

EOF

fi

[ -e "DRV_$1" ] && chmod -R 0777 DRV_$1
[ -e "APP_$1" ] && chmod -R 0777 DRV_$1
[ -e "APP_$1/test.c" ] && cd APP_$1;gcc -o hkapp test.c

