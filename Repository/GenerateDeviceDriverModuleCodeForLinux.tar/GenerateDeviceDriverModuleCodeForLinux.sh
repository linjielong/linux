#!/bin/bash
# Copyright (c) 2013. lin_jie_long@126.com, 2013-6-24. All rights reserved.
#
# GenerateModuleCodeForLinux.sh
#
# $1 --- the filename of the module code.

[ $# != 1 ] && exit 0

if [ -e "$1" ]; then
    echo "Skipped: $1 is exist."
else

cat > $1 << "EOF"
/*
 * Copyright (c) 2013.  lin_jie_long@126.com, 2013. All rights reserved.
 */
EOF

echo "/* $1" >> $1

cat >> $1 << "EOF"
 *
 */

#include <linux/init.h>    /* module_init  module_exit */
#include <linux/module.h>  /* MODULE_LINCENSE */
#include <linux/kernel.h>  /* printk */

#include <linux/fs.h>      /* struct file_operations */
#include <linux/cdev.h>    /* struct cdev */
#include <linux/types.h>   /* dev_t */
#include <linux/kdev_t.h>  /* MAJOR(..) MINOR(..) MKDEV(..) */
#include <linux/slab.h>    /* kmalloc  kfree */ 
#include <linux/ioport.h>  /* release_mem_region */

#include <asm/uaccess.h>   /* copy_from_user */
#include <asm/io.h>        /* ioremap */

#define  virt_cdev_debug() printk("<6>""%s:%s:%d\r\n", __FILE__, __FUNCTION__, __LINE__)

static ssize_t  virt_cdev_open(struct  inode *inode, struct file *file)
{
    virt_cdev_debug();
    return 0;
}

static int virt_cdev_release(struct inode *inode, struct file *file)
{
    virt_cdev_debug();
    return 0;
}

static ssize_t virt_cdev_read(struct file *file, char __user *buf, size_t count, loff_t *ppos)
{
    virt_cdev_debug();
    return 0;
}

static ssize_t virt_cdev_write(struct file *file, const char __user *buf, size_t count, loff_t *ppos)
{
    virt_cdev_debug();
    return 0;
}

static int virt_cdev_ioctl(struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg)
{
    printk("<6>" "cmd=%d  arg=%d\r\n", (int)cmd, (int)arg);
    virt_cdev_debug();
    return 0;
}


static struct file_operations  fops = {
    .owner = THIS_MODULE,
    .open = virt_cdev_open,
    .read = virt_cdev_read,
    .write = virt_cdev_write,
    .release = virt_cdev_release,
    .ioctl = virt_cdev_ioctl,
};

static  struct  cdev    virt_cdev;

static  dev_t   virt_cdev_devid;
static  dev_t   virt_cdev_major_devid = 200;

static  const   char  *virt_cdev_devname = "virt_char_dev";

/* The targets to init the char device:
 *     int cdev_add(struct cdev * p, dev_t dev, unsigned count);
 *     init the registers about the specified char device.
 */
static  int  virt_cdev_init(void)
{
    if (virt_cdev_major_devid) {
        virt_cdev_devid = MKDEV(virt_cdev_major_devid, 0);
        if (register_chrdev_region(virt_cdev_devid, 1, virt_cdev_devname) < 0) {
            printk("<6>" "Failed to register_chrdev_region\r\n");
            return -1;
        }
    } else {
        if (alloc_chrdev_region(&virt_cdev_devid, 0, 1, virt_cdev_devname) < 0) {
            printk("<6>" "Failed to alloc_chrdev_region\r\n");
            return -1;
        }
        virt_cdev_major_devid = MAJOR(virt_cdev_devid);
    }

    cdev_init(&virt_cdev, &fops);
    if (cdev_add(&virt_cdev, virt_cdev_devid, 1)) {
        unregister_chrdev_region(virt_cdev_devid, 1);
        printk("<6>" "Failed to cdev_add\r\n");
        return -1;
    }

    printk("<6>" "virt_cdev_init - devid=0x%x\r\n", virt_cdev_devid);
    return 0;
}

/*
 * The targets to exit the char device:
 *     void cdev_del(struct cdev * p);
 */
static void  virt_cdev_exit(void)
{
    unregister_chrdev_region(virt_cdev_devid, 1);
    cdev_del(&virt_cdev);

    printk("<6>" "virt_cdev_exit\r\n");
}


module_init(virt_cdev_init);
module_exit(virt_cdev_exit);

MODULE_LICENSE("Dual BSD/GPL");
MODULE_AUTHOR("lin_jie_long@126.com");
MODULE_DESCRIPTION("to study the develop of the char device.");

EOF

fi

#########  Makefile #########

if [ -e "./Makefile" ]; then
    echo "Skipped: Makefile is exist."
else

cat > Makefile << "EOF"
# Copyright(c)  2012-2017,  lin_jie_long@126.com.  All rights reserved.
# Created by lin_jie_long@126.com, 2012-12-5

SOURCE = $(wildcard *.c)
OBJECT = $(patsubst %.c, %.o, $(SOURCE))

kernel_dir := /lib/modules/`uname -r`/build
export OBJECT

all::
	@make -C $(kernel_dir) M=`pwd` modules
clean:
	@make -C $(kernel_dir) M=`pwd` clean
	@rm -rf *.markers  *.order

EOF

fi

############  Kbuild #############

if [ -e  "./Kbuild" ]; then
    echo "Skipped: Kbuild is exist."
else

cat > Kbuild << "EOF"
# Copyright(c)  2012-2017,  lin_jie_long@126.com.  All rights reserved.
# Created by lin_jie_long@126.com, 2012-12-5

obj-m := hk.o
hk-y := $(OBJECT)

EOF

fi



