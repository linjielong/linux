#!/bin/bash
# Copyright (c) 2013. lin_jie_long@126.com, 2013-6-24. All rights reserved.
#
# GenerateModuleCodeForLinux.sh
#
# $1 --- the filename of the module code.

[ $# != 1 ] && exit 0

if [ -e "$1" ]; then
    echo "Skipped: $1 is exist."
else

cat > $1 << "EOF"
/*
 * Copyright (c) 2013.  lin_jie_long@126.com, 2013. All rights reserved.
 */
EOF

echo "/* $1" >> $1

cat >> $1 << "EOF"
 *
 */

#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/init.h>

static  int  __init  init_km(void)
{
    printk(KERN_INFO"[file=%s; function=%s; line=%d]\r\n", __FILE__, __FUNCTION__, __LINE__);

    return 0;
}

static  void __exit  exit_km(void)
{
    printk(KERN_INFO"[file=%s; function=%s; line=%d]\r\n", __FILE__, __FUNCTION__, __LINE__);
}

module_init(init_km);
module_exit(exit_km);

MODULE_LICENSE("GPL");

EOF

fi

#########  Makefile #########

if [ -e "./Makefile" ]; then
    echo "Skipped: Makefile is exist."
else

cat > Makefile << "EOF"
# Copyright(c)  2012-2017,  lin_jie_long@126.com.  All rights reserved.
# Created by lin_jie_long@126.com, 2012-12-5

SOURCE = $(wildcard *.c)
OBJECT = $(patsubst %.c, %.o, $(SOURCE))

kernel_dir := /lib/modules/`uname -r`/build
export OBJECT

all::
	@make -C $(kernel_dir) M=`pwd` modules
clean:
	@make -C $(kernel_dir) M=`pwd` clean
	@rm -rf *.markers  *.order

EOF

fi

############  Kbuild #############

if [ -e  "./Kbuild" ]; then
    echo "Skipped: Kbuild is exist."
else

cat > Kbuild << "EOF"
# Copyright(c)  2012-2017,  lin_jie_long@126.com.  All rights reserved.
# Created by lin_jie_long@126.com, 2012-12-5

obj-m := hk.o
hk-y := $(OBJECT)

EOF

fi



